<?php

// Footer
$lang['footer_powered_by']				= "Powered by";
$lang['footer_template_by']				= "Template by";

/* End of file footer_lang.php */
/* Location: ./application/modules/admin/language/english/footer_lang.php */
<?php

// Glavno
$lang['languages']						= "Jeziki";
$lang['languages_description'] 			= "Na tej strani lahko vidite nameščene jezike.";

// Sporočila
$lang['no_languages']					= "Ni nameščenih jezikov.";

// Glava tabele
$lang['th_language']					= "Jezik";
$lang['th_author']						= "Avtor";
$lang['th_author_website']				= "Spletna stran";

/* End of file languages_lang.php */
/* Location: ./application/modules/admin/language/slovene/languages_lang.php */
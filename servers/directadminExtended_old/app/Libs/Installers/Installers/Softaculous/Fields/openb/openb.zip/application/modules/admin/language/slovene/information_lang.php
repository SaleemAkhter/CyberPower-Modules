<?php

// Glavno
$lang['information']					= "Informacije";
$lang['information_description'] 		= "Na tej strani lahko najdete informacije o vaši Open Blog namestitvi.";

// Vsebina
$lang['version']						= "Različica:";
$lang['check_for_upgrades']				= "preveri za posodobitve";
$lang['author']							= "Avtor:";
$lang['official_website']				= "Uradna stran:";
$lang['documentation']					= "Dokumentacija:";
$lang['bugtracker']						= "Sledilnik hroščev:";

/* End of file information_lang.php */
/* Location: ./application/modules/admin/language/slovene/information_lang.php */
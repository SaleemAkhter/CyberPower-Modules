<?php

// General
$lang['templates']						= "Templates";
$lang['templates_description'] 			= "Here you can set the default template.";

// Messages
$lang['successfully_set']				= "Default tempalte has been successfully set";

// Form
$lang['form_choose_template']			= "Choose a template";
$lang['form_template']					= "Template";

/* End of file templates_lang.php */
/* Location: ./application/modules/admin/language/english/templates_lang.php */
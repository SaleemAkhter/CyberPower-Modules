<?php

// General
$lang['information']					= "Information";
$lang['information_description'] 		= "Here you view general information about your Open Blog installation.";

// Content
$lang['version']						= "Version:";
$lang['check_for_upgrades']				= "upgrade check";
$lang['author']							= "Author:";
$lang['official_website']				= "Official website:";
$lang['documentation']					= "Documentation:";
$lang['bugtracker']						= "Bug tracker:";

/* End of file information.php */
/* Location: ./application/modules/admin/language/english/information.php */
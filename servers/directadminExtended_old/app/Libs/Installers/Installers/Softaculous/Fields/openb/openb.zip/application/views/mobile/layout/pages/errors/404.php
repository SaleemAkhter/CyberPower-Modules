<?php header("HTTP/1.1 404 Not Found"); ?>
<div class="post" id="post">
	<h2><?php echo lang('error'); ?> 404</h2>
	<div class="entry"><br /><?php echo lang('not_found'); ?></p></div>
</div>
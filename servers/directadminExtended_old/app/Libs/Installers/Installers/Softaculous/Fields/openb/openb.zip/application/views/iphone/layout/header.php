<div class="toolbar">
	<h1 id="pageTitle"><?php echo $this->system_library->settings['blog_title']; ?></h1>
	<h2 id="pageDescription"><?php echo $this->system_library->settings['blog_description']; ?></h2>
</div>
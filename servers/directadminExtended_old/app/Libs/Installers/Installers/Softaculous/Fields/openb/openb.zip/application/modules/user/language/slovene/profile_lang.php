<?php

// Glavno
$lang['profile']						= "Tvoj profil";
$lang['profile_description']			= "Na tej strani si lahko uredite svoj profil.";

// Sporočila
$lang['successfully_edited']			= "Profil je bil uspešno urejen";

// Obrazec
$lang['form_name']						= "Ime";
$lang['form_username']					= "Uporabniško ime";
$lang['form_display_name']				= "Prikazano ime";

$lang['form_password']					= "Geslo";
$lang['form_retype_password']			= "Ponovi geslo";

$lang['form_contact_info']				= "Kontaktne informacije";
$lang['form_email']						= "E-pošta";
$lang['form_website']					= "Spletna stran";
$lang['form_msn_messenger']				= "MSN messenger";
$lang['form_jabber']					= "Jabber";
$lang['form_about_me']					= "O meni";

$lang['form_username_cant_be_changed']	= "uporabniškega imena ne morate spremeniti";

$lang['edit']							= "Uredi &rsaquo;&rsaquo;";

/* End of file profile_lang.php */
/* Location: ./application/modules/user/language/slovene/profile_lang.php */
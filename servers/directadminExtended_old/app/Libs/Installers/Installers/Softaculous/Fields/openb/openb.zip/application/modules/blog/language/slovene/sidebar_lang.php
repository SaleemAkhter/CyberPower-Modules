<?php

// Stranski meni
$lang['search']							= "Iskanje";
$lang['archives']						= "Arhiv";
$lang['categories']						= "Kategorije";
$lang['tag_cloud']						= "Oblak oznak";
$lang['recent_posts']					= "Zadnja sporočila";
$lang['pages']							= "Strani";
$lang['feeds']							= "Viri";
$lang['links']							= "Povezave";
$lang['other']							= "Ostalo";

// Tag cloud
$lang['no_tags']						= "ni oznak";

// Viri
$lang['feeds_posts']					= "sporočila";
$lang['feeds_comments']					= "komentarji";

// Ostalo
$lang['other_login']					= "Prijava";
$lang['other_register']					= "Registracija";
$lang['other_admin_panel']				= "Nadzorna plošča";
$lang['other_view_profile']				= "Poglej profil";
$lang['other_edit_profile']				= "Uredi profil";
$lang['other_logout']					= "Odjava";

/* End of file sidebar_lang.php */
/* Location: ./application/modules/blog/language/slovene/sidebar_lang.php */
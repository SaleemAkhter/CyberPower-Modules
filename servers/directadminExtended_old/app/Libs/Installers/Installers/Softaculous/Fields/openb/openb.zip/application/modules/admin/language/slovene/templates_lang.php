<?php

// Glavno
$lang['templates']				= "Predloge";
$lang['templates_description'] 	= "Na tej strani lahko nastavitve privzeto predlogo.";

// Sporočila
$lang['successfully_set']		= "Prvizeta predloga je bila uspešno nastavljena";

// Obrazec
$lang['form_choose_template']	= "Izberite predlogo";
$lang['form_template']			= "Predloga";

/* End of file templates_lang.php */
/* Location: ./application/modules/admin/language/slovene/templates_lang.php */
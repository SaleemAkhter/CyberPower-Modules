<div class="title"> <span class="sitename"> <?php echo anchor('admin/dashboard', 'Open Blog'); ?></span>
<div class="slogan"><?php echo lang('header_admin_panel'); ?></div>
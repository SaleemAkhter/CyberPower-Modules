<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['mailtype'] = 'html';
$config['wordwrap'] = TRUE;

/* End of file email.php */
/* Location: ./application/config/email.php */
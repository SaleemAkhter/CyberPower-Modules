<?php

// Glavno
$lang['feed_settings']				= "Nastavitve virov";
$lang['feed_settings_description'] 	= "Na tej strani lahko urejate nastavitve virov.";

// Sporočila
$lang['successfully_updated']		= "Nastavitve virov so bile uspešno posodobljene";

// Obrazec
$lang['form_enable_rss_posts']		= "Omogoči vir RSS za sporočila";
$lang['form_enable_rss_comments']	= "Omogoči vir RSS za komentarje";
$lang['form_enable_atom_posts']		= "Omogoči vir Atom za sporočila";
$lang['form_enable_atom_comments']	= "Omogoči vir Atom za komentarje";

/* End of file feeds_lang.php */
/* Location: ./application/modules/admin/language/slovene/feeds_lang.php */
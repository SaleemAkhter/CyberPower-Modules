<?php

// RSS, Atom komentarji
$lang['comments_for'] 						= "Komentarji za";
$lang['comment_on'] 						= "Komentar na ";
$lang['comment_by'] 						= " od ";

// Vir onemogočen
$lang['feed_disabled'] 						= "Vir onemogočen";
$lang['feed_disabled_description'] 			= "Ta vir je trenutno onemogočen.";

/* End of file feed_lang.php */
/* Location: ./application/modules/feed/language/slovene/feed_lang.php */
<?php

// Glavno
$lang['user_profile']					= "Uporabniški profil ";

// Vsebina
$lang['nickname']						= "Uporabniško ime:";
$lang['display_name']					= "Prikazano ime:";
$lang['date_registered']				= "Registriran:";
$lang['website']						= "Spletna stran:";
$lang['about_me']						= "O meni:";

/* End of file view_lang.php */
/* Location: ./application/modules/user/language/slovene/view_lang.php */
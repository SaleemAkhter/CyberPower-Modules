<?php

// Header
$lang['header_admin_panel']				= "Administration panel";

/* End of file header_lang.php */
/* Location: ./application/modules/admin/language/english/header_lang.php */
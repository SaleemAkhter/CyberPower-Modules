<?php

// Login
$lang['login']							= "Login";

// Messages
$lang['invalid_username']				= "Invalid username or password";

// Form
$lang['form_username']					= "Username:";
$lang['form_password']					= "Password:";

$lang['button_login']					= "Login";

// Other
$lang['register']						= "Register";
$lang['forgotten_password']				= "Forgotten password";

/* End of file login_lang.php */
/* Location: ./application/modules/user/language/english/login_lang.php */
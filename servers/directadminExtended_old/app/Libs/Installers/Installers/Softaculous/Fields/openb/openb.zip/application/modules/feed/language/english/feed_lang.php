<?php

// RSS, Atom comments
$lang['comments_for'] 						= "Comments for";
$lang['comment_on'] 						= "Comment on ";
$lang['comment_by'] 						= "by";

// Feed disabled
$lang['feed_disabled'] 						= "Feed disabled";
$lang['feed_disabled_description'] 			= "This feed is currently disabled.";

/* End of file feed_lang.php */
/* Location: ./application/modules/feed/language/english/feed_lang.php */
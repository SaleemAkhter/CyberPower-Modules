<?php

// General
$lang['button_create']					= "Create &rsaquo;&rsaquo;";
$lang['button_save']					= "Save &rsaquo;&rsaquo;";
$lang['button_edit']					= "Edit &rsaquo;&rsaquo;";

// Buttons
$lang['enable']							= "Enable";
$lang['disable']						= "Disable";
$lang['edit']							= "Edit";
$lang['delete']							= "Delete";

$lang['yes']							= "Yes";
$lang['no']								= "No";

/* End of file general_lang.php */
/* Location: ./application/modules/admin/language/english/general_lang.php */
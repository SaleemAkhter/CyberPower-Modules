<?php

// Glavno
$lang['site_disabled']					= "Stran je trenutno nedosegljiva.";
$lang['reason']							= "Razlog:";

/* End of file system_lang.php */
/* Location: ./application/modules/blog/language/slovene/system_lang.php */
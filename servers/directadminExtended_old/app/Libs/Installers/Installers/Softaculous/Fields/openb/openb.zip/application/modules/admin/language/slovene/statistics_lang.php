<?php

// Glavno
$lang['statistics']						= "Statistika";
$lang['statistics_description'] 		= "Na tej strani se nahaja statistika vašega spletnega dnevnika.";

// Vsebina
$lang['posts']							= "Sporočila:";
$lang['published']						= "objavljenih";
$lang['draft']							= "osnutkov";
$lang['most_popular_post']				= "Najbolj popularno sporočilo:";
$lang['comments_total']					= "komentarjev skupaj";
$lang['categories']						= "Kategorije:";
$lang['category_with_most_posts']		= "Kategorija s največ sporočili:";
$lang['posts_total']					= "sporočil skupaj";
$lang['comments']						= "Komentarji:";
$lang['registered_users']				= "od registriranih uporabnikov";
$lang['guests']							= "od gostov";

/* End of file statistics_lang.php */
/* Location: ./application/modules/admin/language/slovene/statistics_lang.php */
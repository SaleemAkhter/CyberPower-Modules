<?php

$route['pages/(:any)'] = 'pages/page/$1';

/* End of file pages_routes.php */
/* Location: ./application/modules/pages/pages_routes.php */
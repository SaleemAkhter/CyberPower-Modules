<?php

// General
$lang['languages']						= "Languages";
$lang['languages_description'] 			= "Here you can see installed languages.";

// Messages
$lang['no_languages']					= "No languages found.";

// Table header
$lang['th_language']					= "Language";
$lang['th_author']						= "Author";
$lang['th_author_website']				= "Author website";

/* End of file languages_lang.php */
/* Location: ./application/modules/admin/language/english/languages_lang.php */
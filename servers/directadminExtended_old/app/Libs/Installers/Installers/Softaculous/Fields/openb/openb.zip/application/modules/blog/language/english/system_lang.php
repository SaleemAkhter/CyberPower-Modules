<?php

// General
$lang['site_disabled']					= "Site is currently disabled.";
$lang['reason']							= "Reason:";

/* End of file system_lang.php */
/* Location: ./application/modules/blog/language/english/system_lang.php */
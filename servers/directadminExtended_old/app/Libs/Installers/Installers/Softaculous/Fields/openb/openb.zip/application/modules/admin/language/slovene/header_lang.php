<?php

// Glava
$lang['header_admin_panel']					= "Administratorski kotiček";

/* End of file header_lang.php */
/* Location: ./application/modules/admin/language/slovene/header_lang.php */
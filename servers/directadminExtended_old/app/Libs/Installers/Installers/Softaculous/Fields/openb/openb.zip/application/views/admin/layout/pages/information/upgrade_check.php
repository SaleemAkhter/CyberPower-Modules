<div class="post">
		<div class="post_title">
			<h1><?php echo lang('upgrade_check'); ?></h1>
		</div>
		<div class="post_body">
			<p>
				<?php echo lang('current_version'); ?> <strong><?php echo $current_version; ?></strong><br />
				<?php echo lang('latest_version'); ?> <strong><?php echo $latest_version; ?></strong><br/>
				<?php echo lang('status'); ?> <?php echo $status; ?>
			</p>
		</div>
</div>
<?php

// Noga
$lang['footer_powered_by']				= "Poganja";
$lang['footer_template_by']				= "Avtor predloge";

/* End of file footer_lang.php */
/* Location: ./application/modules/admin/language/slovene/footer_lang.php */
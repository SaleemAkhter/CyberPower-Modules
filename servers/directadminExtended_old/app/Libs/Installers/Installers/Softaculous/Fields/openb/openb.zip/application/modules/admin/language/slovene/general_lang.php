<?php

// Glavno
$lang['button_create']					= "Ustvari &rsaquo;&rsaquo;";
$lang['button_save']					= "Shrani &rsaquo;&rsaquo;";
$lang['button_edit']					= "Uredi &rsaquo;&rsaquo;";

// Gumbi
$lang['enable']							= "Omogoči";
$lang['disable']						= "Onemogoči";
$lang['edit']							= "Uredi";
$lang['delete']							= "Izbriši";

$lang['yes']							= "Da";
$lang['no']								= "Ne";

/* End of file general_lang.php */
/* Location: ./application/modules/admin/language/slovene/general_lang.php */
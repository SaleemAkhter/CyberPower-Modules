<div>
    <h2><?php echo $page_data['title']; ?></h2>
    <div class="content"><?php echo $page_data['content']; ?></div>
    <div id="settings" title="Settings" class="panel">
    <p></p>
    <p></p>
    </div>
</div>
<?php

// Prijava
$lang['login']							= "Prijava";

// Sporočila
$lang['invalid_username']				= "Napačno uporabniško ime ali geslo";

// Obrazec
$lang['form_username']					= "Uporabniško ime:";
$lang['form_password']					= "Geslo:";

$lang['button_login']					= "Prijava";

// Ostalo
$lang['register']						= "Registracija";
$lang['forgotten_password']				= "Pozabljeno geslo";

/* End of file login_lang.php */
/* Location: ./application/modules/user/language/slovene/login_lang.php */
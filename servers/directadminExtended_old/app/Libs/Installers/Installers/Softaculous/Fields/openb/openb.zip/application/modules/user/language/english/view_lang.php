<?php

// General
$lang['user_profile']					= "User profile ";

// Content
$lang['nickname']						= "Username:";
$lang['display_name']					= "Display name:";
$lang['date_registered']				= "Date registered:";
$lang['website']						= "Website:";
$lang['about_me']						= "About me:";

/* End of file view_lang.php */
/* Location: ./application/modules/user/language/english/view_lang.php */
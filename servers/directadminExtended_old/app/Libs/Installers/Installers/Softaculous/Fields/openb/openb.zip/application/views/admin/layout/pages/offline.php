<?php echo lang('site_disabled'); ?><br />

<?php echo lang('reason'); ?> <strong><?php echo $offline_reason; ?></strong>
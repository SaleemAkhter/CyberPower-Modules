<div id="footer">
	<p>
		<?php echo lang('footer_powered_by'); ?> <a href="http://www.open-blog.info" target="_blank">Open Blog</a> | <?php echo lang('footer_template_by'); ?> <a href="http://imthi.com/wp-pda/" target="_blank">imthiaz</a>
	</p>
</div>